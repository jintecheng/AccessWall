package main // local ip : 192.168.1.44

import (
	"log"

	"github.com/joho/godotenv"
	R "github.com/mail_encryption/routes"
	//R "github.com/jintecheng/yu/v1/routes"
)

func main() {

	err := godotenv.Load("config.env")
	if err != nil {
		log.Fatal("Error loading .env file")
	}

	R.Server()
}
